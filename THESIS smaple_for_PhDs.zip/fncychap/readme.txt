FNCYCHAP Readme-file (Release 5 v1.3) 2004/09/20

To install this put the sty file in a directory searched by TeX. 
The LaTeX-base has to be post 1994/12/01.
However, a warning will be given if the base is
older than 1995/12/01.

Print the user documentation contained in the file FncyChap.pdf

Report bugs and questions to

Ulf Lindgren 
  ulf DOT a DOT lindgren AT ericsson DOT com

